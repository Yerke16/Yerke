package kz.aitu.oop.assignment_6;
public interface CoffeeTable {
    public void description();
    public void showMaterial();
}
