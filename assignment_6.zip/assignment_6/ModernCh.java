package kz.aitu.oop.assignment_6;
public class ModernCh implements Chairr {
    @Override
    public void description() {
        System.out.println("This is modern chair");
    }

    @Override
    public boolean hasLegs() {
        System.out.println("Chair has legs:");
        return true;
    }

    @Override
    public boolean sitOn() {
        return false;
    }
}
