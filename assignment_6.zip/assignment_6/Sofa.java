package kz.aitu.oop.assignment_6;
public interface Sofa {
    public void description();
    public void showQuality();
}
