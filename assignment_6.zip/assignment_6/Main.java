package kz.aitu.oop.assignment_6;
public class Main {
    public static void main(String[] args) {
Chairr chairr = new VictorianCh();
chairr.description();
    }
}

