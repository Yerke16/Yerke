package kz.aitu.oop.assignment_6;
public class VictorianCh implements Chairr{
    @Override
    public void description() {
        System.out.println("This is victorian chair.");
    }

    @Override
    public boolean hasLegs() {
        return true;
    }

    @Override
    public boolean sitOn() {
        return false;
    }
}
