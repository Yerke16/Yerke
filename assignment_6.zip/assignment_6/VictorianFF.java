package kz.aitu.oop.assignment_6;
public class VictorianFF implements FF{
    @Override
    public Chairr getChair() {
        return new VictorianCh();
    }

    @Override
    public Sofa getSofa() {
        return new VictorianS();
    }

    @Override
    public CoffeeTable getCoffeeTable() {
        return new VictorianCT();
    }
}
