package kz.aitu.oop.assignment_6;
public interface FF {
    Chairr getChair();
    Sofa getSofa();
    CoffeeTable getCoffeeTable();
}
