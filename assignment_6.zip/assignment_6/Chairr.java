package kz.aitu.oop.assignment_6;
public interface Chairr {
    public void description();
    public boolean hasLegs();
    public boolean sitOn();
}
