package kz.aitu.oop.assignment_6;
public class ModernFF implements FF {

    @Override
    public Chairr getChair() {
        return new ModernCh();
    }

    @Override
    public Sofa getSofa() {
        return new ModernS();
    }

    @Override
    public CoffeeTable getCoffeeTable() {
        return new ModernCT();
    }
}
