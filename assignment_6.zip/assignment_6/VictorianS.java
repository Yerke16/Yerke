package kz.aitu.oop.assignment_6;
public class VictorianS implements Sofa{
    @Override
    public void description() {
        System.out.println("This is victorian sofa.");
    }

    @Override
    public void showQuality() {
        System.out.println("Victorian sofa is old.");
    }
}
